using NUnit.Framework;
using TMPro;
using UnityEngine;
using System.Collections.Generic;

class PointInTime{
    public Vector3 position;
    public Quaternion rotation;
    public PointInTime(Vector3 position, Quaternion rotation)
    {
        this.position = position;
        this.rotation = rotation;
    }   

}

public class TimeBody : MonoBehaviour
{
    public bool isRewinding = false;
    Rigidbody rb;
    public float recordTime = 5f;
    public TextNumberReverseClocksController textNumberReverseClocksController;



    List<PointInTime> pointsInTime;

    void Awake()
    {
        Debug.Log("El Script: (Time Body) Empez� a Ejecutarse!");
        pointsInTime = new List<PointInTime>();
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {

        if (Input.GetKeyDown(KeyCode.R))
        {
            if (!isRewinding && textNumberReverseClocksController.CanRewind())
            {
                StartRewind();
            }
        }
    }
    private void StartRewind()
    {
        rb.isKinematic = true;
        isRewinding = true;
    }

    private void StopRewind()
    {
        rb.isKinematic = false;
        isRewinding = false;
    }

    public void FixedUpdate()
    {
        if (isRewinding)
        {
            Rewind();
        }
        else
        {
            Record();
        }
    }

    private void Rewind()
    {
        if (pointsInTime.Count > 0)
        {
            transform.position = pointsInTime[0].position;
            transform.rotation = pointsInTime[0].rotation;
            pointsInTime.RemoveAt(0);
        }
        else {
            StopRewind();
        }
    }

    private void Record()
    {
        if (pointsInTime.Count > Mathf.Round(recordTime / Time.fixedDeltaTime))
        {
            pointsInTime.RemoveAt(pointsInTime.Count - 1);
        }
        Vector3 objectPosition = transform.position;
        Quaternion objectRotation = transform.rotation;
        PointInTime pointInTime = new PointInTime(objectPosition, objectRotation);
        pointsInTime.Insert(0, pointInTime);
    }
}
