using UnityEngine;
using UnityEngine.Audio;

public class AudioManager : MonoBehaviour
{
    public GameObject AudioManager_GameObject;
    public AudioMixer audioMixer;

    private AudioSource music_AudioSource;
    private AudioSource sfx_AudioSource;
    private float musicVolume;
    private float sfxVolume;
    void Start()
    {
        music_AudioSource = AudioManager_GameObject.GetComponents<AudioSource>()[0];
        sfx_AudioSource = AudioManager_GameObject.GetComponents<AudioSource>()[1];
        musicVolume = PlayerPrefs.GetFloat("Music");
        sfxVolume = PlayerPrefs.GetFloat("SFX");

        audioMixer.SetFloat("Music", musicVolume);
        audioMixer.SetFloat("SFX", sfxVolume);

        music_AudioSource.Play();
    }
}
