using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public GameObject Canvas;
    private GameObject mainMenu;
    private GameObject mainOptions;

    public void Start()
    {
        Cursor.lockState = CursorLockMode.None;
        mainMenu = Canvas.transform.Find("Main-Menu").gameObject;
        mainOptions = Canvas.transform.Find("Main-Options").gameObject;

        ShowMainMenu();
    }

    public void PlayGame() {

        SceneManager.LoadSceneAsync(1);
    }

    public void QuitGame() {
        Application.Quit();
    }

    public void ShowMainMenu() {
        mainMenu.SetActive(true);
        mainOptions.SetActive(false);
    }

    public void ShowMainOptions()
    {
        mainMenu.SetActive(false);
        mainOptions.SetActive(true);
    }

}
