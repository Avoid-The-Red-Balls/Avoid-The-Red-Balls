using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class MainOptions : MonoBehaviour
{
    public Slider musicSlider;
    public Slider sfxSlider;
    public AudioMixer audioMixer;
    public GameObject AudioManager;
    private AudioSource musicAudioSource;
    private AudioSource sfxAudioSource;
    private bool canEditVolume = false;

    public void Start()
    {
        musicAudioSource = AudioManager.GetComponents<AudioSource>()[0];
        sfxAudioSource = AudioManager.GetComponents<AudioSource>()[1];

        float musicVolume = 0f;
        if (audioMixer.GetFloat("Music", out musicVolume)){
            musicSlider.value = convertToSliderValue(musicVolume);
        }
        float sfxVolume = 0f;
        if (audioMixer.GetFloat("SFX", out sfxVolume)) {
            sfxSlider.value = convertToSliderValue(sfxVolume);
        }
        canEditVolume = true;
    }

    private float convertToVolume(float musicSliderValue) {
        float volume = Mathf.Log10(Mathf.Clamp(musicSliderValue, 0.0001f, 1f)) * 20;
        return volume;
    }

    private float convertToSliderValue(float volume) {
        return Mathf.Pow(10f, volume / 20f);
    }

    public void ChangeMusicVolume() {
        if (!canEditVolume) return;

        float volume = convertToVolume(musicSlider.value);
        audioMixer.SetFloat("Music", volume);
        PlayerPrefs.SetFloat("Music", volume);

        musicAudioSource.Play();
        sfxAudioSource.Stop();
    }

    public void ChangeSFXVolume() {
        if (!canEditVolume) return;

        float volume = convertToVolume(sfxSlider.value);
        audioMixer.SetFloat("SFX", volume);
        PlayerPrefs.SetFloat("SFX", volume);

        musicAudioSource.Stop();
        sfxAudioSource.Play();
    }
}
