using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class TextPointsController : MonoBehaviour
{
    public TextMeshProUGUI Text_Points;
    public float points_float = 0f;
    private int points_int = 0;
    public float points_add_velocity = 1f;

    public GameObject Items;
    public GameObject Balls;
    private GameObject RedBall;
    private GameObject BlueBall;
    public GameObject TopWall;
    public GameObject RightXWall;

    public float redBalls_spawn_velocity = 1 / 2;

    public float maxTimeWaitedSpawnBall = 5;
    public float decreaseMaxTimeWaitedSpawnBall = .01f;
    public float maxForceApplyToBallSpawn = .01f;

    public TimeBody timeBody;

    private void applyForceToBall(GameObject ball) {
        Rigidbody rb = ball.GetComponent<Rigidbody>();
        Vector3 randomDirection = getRandomPositionInBox().normalized;
        randomDirection.y = 0;
        rb.AddForce(randomDirection * maxForceApplyToBallSpawn, ForceMode.Impulse);
    }

    private Vector3 getRandomPositionInBox() {
        float WallThickness = TopWall.transform.localScale.y;
        float BallRadius = BlueBall.transform.localScale.y / 2;

        float MaxXBox = (RightXWall.transform.position.x - WallThickness - BallRadius);
        float MaxYBox = (TopWall.transform.position.y - WallThickness - BallRadius);
        float MaxZBox = (RightXWall.transform.position.z - WallThickness - BallRadius);

        float x = Random.Range(-MaxXBox, MaxXBox);
        float y = MaxYBox;
        float z = Random.Range(-MaxZBox, MaxZBox);

        return new Vector3(x, y, z);
    }
    
    private void spawnBall(string ballType) {
        string cleanBallType = ballType.Trim().ToLower();
        Vector3 ball_position = getRandomPositionInBox();
        GameObject ball = null;

        if (cleanBallType.Equals("red-ball")) {
            ball = Instantiate(RedBall, ball_position, Quaternion.identity, null);
            ball.name = "Red-Ball";
            applyForceToBall(ball);
        }

        else if (cleanBallType.Equals("blue-ball")) {
            ball = Instantiate(BlueBall, ball_position, Quaternion.identity, null);
            ball.name = "Blue-Ball";
            applyForceToBall(ball);
        }

        ball.transform.localScale = Vector3.one;
        ball.transform.SetParent(Balls.transform);
    }


    void Start()
    {
        RedBall = Items.transform.Find("Red-Ball").gameObject;
        BlueBall = Items.transform.Find("Blue-Ball").gameObject;

        Text_Points = GetComponent<TextMeshProUGUI>();
        points_add_velocity /= 1000f;
    }

    float timeWaitedSpawnBall = 0;

    void Update()
    {
        timeWaitedSpawnBall += Time.deltaTime;
        if (timeWaitedSpawnBall > maxTimeWaitedSpawnBall) {
            timeWaitedSpawnBall = 0;
            maxTimeWaitedSpawnBall -= decreaseMaxTimeWaitedSpawnBall;
            spawnBall("Red-Ball");
            spawnBall("Blue-Ball");
        }

        points_float += Time.deltaTime * points_add_velocity;
        points_add_velocity += .0001f;
        points_int = (int)Mathf.Round(points_float);
        Text_Points.text = points_int.ToString() + " Points";
    }
}
