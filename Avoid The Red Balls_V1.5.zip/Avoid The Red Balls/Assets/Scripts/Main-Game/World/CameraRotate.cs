using UnityEngine;

public class CameraRotate : MonoBehaviour
{
    public float sensibility = -5f;

    public float maxVerticalAngle = 60f;
    public float minVerticalAngle = -60f;

    private Vector3 rotate;
    
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        float x = Input.GetAxis("Mouse X");
        float y = Input.GetAxis("Mouse Y");

        rotate = new Vector3(y, -x, 0) * sensibility;
        Vector3 newEulerAngles = transform.eulerAngles + rotate;

        if (newEulerAngles.x > 180) newEulerAngles.x -= 360;

        newEulerAngles.x = Mathf.Clamp(newEulerAngles.x, minVerticalAngle, maxVerticalAngle);
        
        transform.eulerAngles = newEulerAngles;
    }
}
