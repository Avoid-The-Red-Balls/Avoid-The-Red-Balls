using NUnit.Framework;
using TMPro;
using UnityEngine;
using System.Collections.Generic;

class PointInTime{
    public Vector3 position;
    public Quaternion rotation;
    public Vector3 velocity;
    public PointInTime(Vector3 position, Quaternion rotation, Vector3 velocity)
    {
        this.position = position;
        this.rotation = rotation;
        this.velocity = velocity;
    }   

}

public class TimeBody : MonoBehaviour
{
    public bool isRewinding = false;
    Rigidbody rb;
    public float recordTime = 5f;
    public TextNumberReverseClocksController textNumberReverseClocksController;



    List<PointInTime> pointsInTime;

    void Awake()
    {
        pointsInTime = new List<PointInTime>();
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {

        if (Input.GetKeyDown(KeyCode.R))
        {

            if (!isRewinding && textNumberReverseClocksController.CanRewind())
            {
                StartRewind();
            }
        }
    }
    private void StartRewind()
    {
        Debug.Log("The Rewind Started");
        rb.isKinematic = true;
        isRewinding = true;
    }

    private void StopRewind()
    {
        rb.isKinematic = false;
        isRewinding = false;

        if (pointsInTime.Count > 0) {
            Vector3 lastObjectVelocity = pointsInTime[0].velocity;
            pointsInTime.RemoveAt(0);
            rb.linearVelocity = lastObjectVelocity;
        }
    }

    public void FixedUpdate()
    {
        if (isRewinding)
        {
            Rewind();
        }
        else
        {
            Record();
        }
    }

    private void Rewind()
    {
        if (pointsInTime.Count > 1)
        {
            transform.position = pointsInTime[0].position;
            transform.rotation = pointsInTime[0].rotation;
            pointsInTime.RemoveAt(0);
        }
        else {
            StopRewind();
        }
    }

    private void Record()
    {
        if (pointsInTime.Count > Mathf.Round(recordTime / Time.fixedDeltaTime))
        {
            pointsInTime.RemoveAt(pointsInTime.Count - 1);
        }
        Vector3 objectPosition = transform.position;
        Quaternion objectRotation = transform.rotation;
        Vector3 objectVelocity = rb.linearVelocity;
        PointInTime pointInTime = new PointInTime(objectPosition, objectRotation, objectVelocity);
        pointsInTime.Insert(0, pointInTime);

        Debug.Log("Recording: " + objectPosition);

    }
}
