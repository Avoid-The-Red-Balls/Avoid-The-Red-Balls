using UnityEngine;

public class BlueBallController : MonoBehaviour
{
    GameObject thisBlueBall;
    public bool isThrowed = false;
    public PlayerController playerController;
    public TextPointsController textPointsController;
    public float incrementHitedBall = 2f;
    public int maxRedBallsCanDisappear = 1;
    void Start()
    {
        thisBlueBall = this.gameObject;
    }

    private void selfDestroy() {
        Destroy(transform.gameObject);
    }
    private void playObjectAnimation(GameObject gameObject, string animationName) {
        Animation animation = gameObject.GetComponent<Animation>();
        animation.Play(animationName);
    }

    public bool ballMatchBlueBallHolded(GameObject blueBall_T) {
        if (blueBall_T.tag.Equals("Red-Ball")) { return false; }

        foreach (GameObject blueBall in playerController.getBlueBallsHolded()) {
            if (blueBall_T == blueBall) {
                return true;
            }
        }
        return false;
    }

    public bool RedBallCanDisappear() {
        return maxRedBallsCanDisappear > 0;
    }

    private void OnCollisionEnter(Collision collision)
    {
        GameObject ballColisioned = collision.gameObject;

        string tagName = ballColisioned.tag;

        bool notThisBlueBallMatchBlueBallHolded = !ballMatchBlueBallHolded(thisBlueBall);
        
        if (tagName.Equals("Red-Ball") && this.isThrowed && notThisBlueBallMatchBlueBallHolded && RedBallCanDisappear())
        {
            maxRedBallsCanDisappear -= 1;
            playObjectAnimation(collision.gameObject, "Ball_Disappear");
            playObjectAnimation(transform.gameObject, "Ball_Disappear");
            textPointsController.points_float += incrementHitedBall;
        }
    }
}
