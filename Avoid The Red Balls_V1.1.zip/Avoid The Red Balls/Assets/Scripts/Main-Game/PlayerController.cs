using NUnit.Framework.Constraints;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;


public class PlayerController : MonoBehaviour
{
    public float speed = 10;
    private Rigidbody rb;
    private MeshRenderer meshRenderer;
    private GameObject cameraObject;

    public float jumpHeight = 6;
    public Transform groundCheck;
    public float groundDistance = .3f;
    public LayerMask groundMask;

    public float dodgeAcceleration = 50;
    public float maxTimeDodging = .15f;
    private bool isDodging = false;

    public Transform HoldPosition;
    public bool isHolding = false;
    public float distanceHolding = 2;
    public Material MaterialBallHolded;
    public Material MaterialBallNotHolded;
    public float impulseThrowBallForce = 20f;
    
    public void Start() {
        rb = GetComponent<Rigidbody>();
        cameraObject = transform.Find("Camera").gameObject;
    }

    public List<GameObject> getBlueBallsHolded() {
        Transform holdPosition = HoldPosition.transform;
        List<GameObject> blueBallsHolded = new List<GameObject>();

        foreach (Transform blueBall in holdPosition) {
            if (blueBall.tag.Equals("Blue-Ball")) {
                blueBallsHolded.Add(blueBall.gameObject);
            }
        }
        return blueBallsHolded;
    }

    public bool isBlueBallInBlueBallsHolded(GameObject blueBall_T)
    {
        if (blueBall_T != null && blueBall_T.transform != null && blueBall_T.transform.parent != null)
        {
            return blueBall_T.transform.parent == HoldPosition;
        }
        return false;
    }

    public void Update()
    {
        codeForMove();
        codeForDodge();        
        codeForJump();
        codeForRotateHoldPosition();
    }

    public void codeForMove() {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");


        Vector3 cameraDirection = cameraObject.transform.forward.normalized;
        Vector3 playerDirectionVertical = new Vector3(cameraDirection.x, 0, cameraDirection.z).normalized;
        Vector3 playerDirectionHorizontal = new Vector3(cameraDirection.z, 0, -cameraDirection.x).normalized;
        Vector3 playerMoveVertical = playerDirectionVertical * speed * moveVertical;
        Vector3 playerMoveHorizontal = playerDirectionHorizontal * speed * moveHorizontal;
        Vector3 newVelocity = playerMoveVertical + playerMoveHorizontal;
    }

    public void codeForRotateHoldPosition() {
        Vector3 cameraDirection = cameraObject.transform.forward.normalized;

        if (isHolding)
        {
            HoldPosition.position = transform.position + cameraDirection * distanceHolding;
        }
    }

    public void codeForDodge() {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 cameraDirection = cameraObject.transform.forward.normalized;
        Vector3 playerDirectionVertical = new Vector3(cameraDirection.x, 0, cameraDirection.z).normalized;
        Vector3 playerDirectionHorizontal = new Vector3(cameraDirection.z, 0, -cameraDirection.x).normalized;
        Vector3 playerMoveVertical = playerDirectionVertical * speed * moveVertical;
        Vector3 playerMoveHorizontal = playerDirectionHorizontal * speed * moveHorizontal;
        Vector3 newVelocity = playerMoveVertical + playerMoveHorizontal;

        if (!isDodging)
        {
            newVelocity.y = rb.linearVelocity.y;
            rb.linearVelocity = newVelocity;

            if (Input.GetKeyDown(KeyCode.E))
            {
                isDodging = true;
                rb.AddForce(playerDirectionHorizontal * dodgeAcceleration, ForceMode.Impulse);
                Invoke("makeIsDodgingEqualFalse", maxTimeDodging);
            }
            else if (Input.GetKeyDown(KeyCode.Q))
            {
                isDodging = true;
                rb.AddForce(playerDirectionHorizontal * -dodgeAcceleration, ForceMode.Impulse);
                Invoke("makeIsDodgingEqualFalse", maxTimeDodging);
            }
        }
    }

    public void codeForJump() {
        bool isGrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask);
        Vector3 cameraDirection = cameraObject.transform.forward.normalized;


        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            float jumpVelocity = Mathf.Sqrt(jumpHeight * -2 * Physics.gravity.y);
            rb.AddForce(Vector3.up * jumpVelocity, ForceMode.Impulse);
        }

        if (Input.GetMouseButtonDown(0) && getBlueBallsHolded().Count > 0)
        {
            throwBall(getBlueBallsHolded()[0], cameraDirection);
        }
    }

    public void holdBall(GameObject gameObject) {
        gameObject.GetComponent<Renderer>().material = MaterialBallHolded;
        gameObject.GetComponent<Collider>().enabled = false;
        Rigidbody rb = gameObject.GetComponent<Rigidbody>();
        rb.useGravity = false;
        rb.isKinematic = true;
        rb.transform.SetParent(HoldPosition);
        rb.transform.localPosition = Vector3.zero;
        isHolding = true;
    }

    public void throwBall(GameObject gameObject, Vector3 direction){
        Rigidbody rb = gameObject.GetComponent<Rigidbody>();
        rb.useGravity = true;
        rb.isKinematic = false;
        rb.transform.SetParent(null, true);
        rb.AddForce(direction * impulseThrowBallForce, ForceMode.Impulse);
        BlueBallController blueBallController = gameObject.GetComponent<BlueBallController>();
        
        if (getBlueBallsHolded().Count == 0) {
            isHolding = false;
        }
        gameObject.GetComponent<Collider>().enabled = true;
        blueBallController.isThrowed = true;
    }

    public void makeIsDodgingEqualFalse() {
        isDodging = false;
    }

    void OnCollisionEnter(Collision collision)
    {
        Vector3 cameraDirection = cameraObject.transform.forward;

        string tagName = collision.gameObject.tag;

        if (tagName.Equals("Red-Ball"))
        {
            SceneManager.LoadSceneAsync(0);
        }
        else if (tagName.Equals("Blue-Ball")) {
            holdBall(collision.gameObject);
        }


    }


}
