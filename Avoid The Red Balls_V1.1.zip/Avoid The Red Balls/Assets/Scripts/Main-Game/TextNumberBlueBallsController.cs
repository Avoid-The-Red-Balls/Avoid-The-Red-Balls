using TMPro;
using UnityEngine;

public class TextNumberBlueBallsController : MonoBehaviour
{
    public PlayerController playerController;
    private TextMeshProUGUI Text_Number_Blue_Balls;
    void Start()
    {
        Text_Number_Blue_Balls = GetComponent<TextMeshProUGUI>();
    }

    void Update()
    {
        int numberOfBlueBallsHolded = playerController.getBlueBallsHolded().Count;
        Text_Number_Blue_Balls.text = "x" + numberOfBlueBallsHolded.ToString();
    }
}
