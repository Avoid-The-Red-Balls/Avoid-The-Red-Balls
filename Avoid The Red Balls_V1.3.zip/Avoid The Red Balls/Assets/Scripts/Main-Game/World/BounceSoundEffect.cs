using UnityEngine;

public class BounceSoundEffect : MonoBehaviour
{
    public GameObject AudioManager;
    private AudioSource bounceSound_AudioSource;
    public AudioClip bounceSound_AudioClip;
    private float bounceCooldown = 1f; 
    private float nextBounceTime = 0f;
    public void Start()
    {
        bounceSound_AudioSource = AudioManager.GetComponents<AudioSource>()[1];
    }
    public void OnCollisionEnter(Collision collision)
    {
        string tagName = collision.gameObject.tag.ToLower().Trim();

        if (tagName.Equals("wall") || tagName.Equals("ground") || tagName.Equals("red-Ball") || tagName.Equals("blue-ball") 
            && Time.time >= nextBounceTime) {
            bounceSound_AudioSource.PlayOneShot(bounceSound_AudioClip);
            nextBounceTime = Time.time + bounceCooldown;
        }
    }
}
