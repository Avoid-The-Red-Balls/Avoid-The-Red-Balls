using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuTextController : MonoBehaviour
{
    public void CheckToWantToChangeSceneToMainMenu() {
        if (Input.GetKeyDown(KeyCode.M)) {
            SceneManager.LoadScene(0);
        }
    }

    public void Update()
    {
        CheckToWantToChangeSceneToMainMenu();
    }
}
