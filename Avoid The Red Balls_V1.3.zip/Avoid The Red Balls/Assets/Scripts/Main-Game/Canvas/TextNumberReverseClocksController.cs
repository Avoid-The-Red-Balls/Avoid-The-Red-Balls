using NUnit.Framework;
using TMPro;
using UnityEngine;
using System.Collections.Generic;

public class TextNumberReverseClocksController : MonoBehaviour
{
    private TextMeshProUGUI Text_NumberRewindClockController;

    public int maxNumberOfRewindsAvailable = 2;

    public int NumberOfRewindsAvailable
    {
        get { return maxNumberOfRewindsAvailable; }
        set
        {
            if (value < 0)
                maxNumberOfRewindsAvailable = 0;
            else {
                maxNumberOfRewindsAvailable = value;
            }
        }
    }

    public void Start()
    {
        Text_NumberRewindClockController = GetComponent<TextMeshProUGUI>();
        NumberOfRewindsAvailable = maxNumberOfRewindsAvailable;
    }

    public void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            Invoke("SubtractRewindClockController", .1f);
        }
    }

    public bool CanRewind()
    {
        return NumberOfRewindsAvailable > 0;
    }

    public void SubtractRewindClockController()
    {
        NumberOfRewindsAvailable--;
        Text_NumberRewindClockController.text = "x" + NumberOfRewindsAvailable.ToString();
    }




}
